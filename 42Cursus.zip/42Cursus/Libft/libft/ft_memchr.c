/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 15:13:59 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/05 22:28:30 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *str, int find, size_t n)
{
	char	*casted_str;

	casted_str = (char *)str;
	while (n--)
		if (*(casted_str++) == (char)find)
			return ((void *)(--casted_str));
	return (NULL);
}
