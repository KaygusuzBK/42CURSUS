/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 13:20:57 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/05 22:38:28 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


char    *strdup(const char *str)
{
    size_t len = ft_strlen(str) + 1;
    char *dst = ft_calloc(len);
    if (dst == NULL)
    {
        return (NULL);
    }
}
