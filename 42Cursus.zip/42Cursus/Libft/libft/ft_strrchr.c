/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 09:39:42 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/05 22:46:52 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strrchr(const char *str, int find)
{
	int	index;

	index = ft_strlen(str);
	while (index >= 0)
	{
		if (*((char *)(str + index)) == (char)(find))
			return ((char *)(str + index));
		index--;
	}
	return (NULL);
}
