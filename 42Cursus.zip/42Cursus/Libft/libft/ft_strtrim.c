/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 11:37:11 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/05 22:48:31 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char *ft_strtrim, char const *s1, char const *set)
{
	int	start;
	int	end;
	int	*result;

	start = 0;
	end = ft_strlen(s1);
}
