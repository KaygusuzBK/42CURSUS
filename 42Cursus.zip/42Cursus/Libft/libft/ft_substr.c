/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 09:51:05 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/05 22:50:01 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*substr;

	if (start > ft_strlen(s))
		return (ft_strdup(""));
	if (n > ft_strlen(s + start))
		n = ft_strlen(s + start);
	substr = ft_calloc(n + 1, sizeof(char));
	if (!substr)
		return (NULL);
	while (n && *((char *)(str + start + --n)))
		*(substr + n) = *((char *)(str + start + n));
	return (substr);
}
