/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/10 03:14:07 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/04 11:38:56 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void *ft_memcpy(void *dst, const void *src, size_t n)
{
	char *ptr_d;
	char *ptr_s;
	size_t i; // pozitif 

	ptr_d = (char *)dst; // dst'i chara çeviriyoz
	ptr_s = (char *)src;
	if (!dst && !src)
		return (0);
	i = 0;
	while (i < n)
	{
		*(ptr_d + i) = *(ptr_s + i); // kopyalama işlemini dönüyo
		i++;
	}
	return (dst); 
}
