/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/10 03:14:07 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/04 14:20:36 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void *ft_memmove(void *dst, const void *src, size_t len)
{
	size_t i;
	unsigned char *from;
	unsigned char *to;
	unsigned char temp[len];

	if (dst == NULL || src == NULL) // boşsa
		return (0);
	i = 0;
	from = (unsigned char *)src;
	to = (unsigned char *)dst;
	while (i < len)
	{
		*(temp + i) = *(from + i); 
		i++;
	}
	while (i--) // tersten yazdırmamızın sebebi, eğer aynı yerden başlarsak, önceki değerlerin üzerine yazmamız olur.
		*(to + i) = *(temp + i); 
	return (dst);
}
int main()
{
	char str[] = "bkaygusu";
	ft_memmove(str + 2, str, 5);
	printf("%s", str);
}