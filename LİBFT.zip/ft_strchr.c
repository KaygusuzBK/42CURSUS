/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/10 03:14:07 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/04 14:34:43 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char *ft_strchr(const char *s, int c)
{
	int i;
	char ch;

	i = 0;
	ch = c;
	while (*(s + i) != '\0') // sonuna kadar
	{
		if (*(s + i) == ch)			// eger karakter bulunduysa
			return ((char *)s + i); // bulunan karakterin adresini dondur
		i++;
	}
	if (ch == '\0')
		return ((char *)s + i);
	return (NULL);
}
