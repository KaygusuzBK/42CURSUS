/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bkaygusu <bkaygusu@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/10 03:14:07 by bkaygusu          #+#    #+#             */
/*   Updated: 2022/10/04 14:25:16 by bkaygusu         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t dst_len;
	size_t offset;
	int src_i;

	dst_len = ft_strlen(dst); // dest stringin uzunlugunu bul
	offset = dst_len;		  // offseti dest stringin uzunluguna esitle
	src_i = 0;
	if (dstsize < dst_len + 1) // dstsize dest stringin uzunlugundan kucukse
		return (ft_strlen(src) + dstsize);
	if (dstsize > dst_len + 1)
	{
		while (*(src + src_i) && offset < dstsize - 1) // src stringin sonuna kadar veya dstsize-1 kadar
			*(dst + offset++) = *(src + src_i++);	   // dest stringe src stringi kopyala
		*(dst + offset) = '\0';
	}
	return (dst_len + ft_strlen(src));
}
